package ir.mirrajabi.persiancalendar.core.exceptions;

/**
 * @author Amir
 */

public class DayOutOfRangeException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = -9053871584605015203L;

    public DayOutOfRangeException() {
        super();

    }

    public DayOutOfRangeException(String arg0) {
        super(arg0);

    }

}
