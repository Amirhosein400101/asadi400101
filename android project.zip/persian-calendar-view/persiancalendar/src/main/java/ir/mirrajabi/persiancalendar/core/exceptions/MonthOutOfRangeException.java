package ir.mirrajabi.persiancalendar.core.exceptions;

/**
 * @author Amir
 */

public class MonthOutOfRangeException extends RuntimeException {
    private static final long serialVersionUID = 1871328381608677472L;

    public MonthOutOfRangeException() {
        super();
    }

    public MonthOutOfRangeException(String arg0) {
        super(arg0);
    }

}
