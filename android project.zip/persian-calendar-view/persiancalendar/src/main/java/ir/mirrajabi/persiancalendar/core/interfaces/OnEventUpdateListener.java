package ir.mirrajabi.persiancalendar.core.interfaces;

/**
 * Created by MADNESS on 3/23/2017.
 */

public interface OnEventUpdateListener {
    void update();
}
