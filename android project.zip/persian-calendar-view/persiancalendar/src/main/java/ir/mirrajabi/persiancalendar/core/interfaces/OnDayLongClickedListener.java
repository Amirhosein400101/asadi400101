package ir.mirrajabi.persiancalendar.core.interfaces;

import ir.mirrajabi.persiancalendar.core.models.PersianDate;

/**
 * Created by MADNESS on 3/23/2017.
 */

public interface OnDayLongClickedListener {
    void onLongClick(PersianDate date);
}
